package Bai3;

public interface Payment {
    void pay(double amount);
}
