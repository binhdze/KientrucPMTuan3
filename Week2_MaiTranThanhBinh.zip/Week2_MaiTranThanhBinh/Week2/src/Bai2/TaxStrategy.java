package Bai2;

public interface TaxStrategy {
    double calculateTax(double price);
}