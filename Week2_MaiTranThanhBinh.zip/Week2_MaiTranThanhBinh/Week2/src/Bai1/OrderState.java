package Bai1;

public interface OrderState {
    void handle(Order order);

}
